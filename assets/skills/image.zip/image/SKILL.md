---
name: "image"
description: "Image prompting skill — пишет готовые промпты для двух семей моделей: Nano Banana (NB2 Lite / NB2 / NBP, Gemini 3.x Flash-Lite / Flash / Pro) и GPT Image 2.5 от OpenAI (Flare / Sunburst, а также legacy gpt-image-2), включая ChatGPT Images 2.5. Skill сам не запускает генерацию, только формирует промпт и помечает модель / quality / size / background. Use when пользователь говорит \"нарисуй\", \"сгенерируй картинку\", \"сделай изображение\", \"напиши промпт для image gen\", \"промпт для ChatGPT картинки\", запрашивает blog covers, slides, инфографику, постер, product shot, стикер или иконку с прозрачным фоном, UI mockup, storyboard, comic, character sheet, edit/colorize, virtual try-on, style transfer. Triggers: \"image prompt\", \"промпт для картинки\", nb, nano banana, NBP, NB2, NB2 Lite, gpt-image, gpt image 2, gpt-image-2.5, flare, sunburst, \"ChatGPT Images\", \"images 2.5\", \"AI image\". Do NOT use for: video (use video skill), 3D models, audio, non-image tasks."
---

# Image Prompting — Nano Banana & GPT Image 2.5

This skill writes image prompts. It does not generate images. The output is: model name + quality / size / aspect ratio (+ background when relevant) + the prompt itself.

The body of this SKILL.md is intentionally thin on craft so you cannot fake a result by reading it alone. The actual rules — what the models reward, what they punish, how to phrase a 5-slot template, when to raise quality, when to use image grounding — live in the reference files. The one exception is the section **"Актуальные модели (сентябрь 2026)"** below: the reference files were written before GPT Image 2.5 and Nano Banana 2 Lite shipped, so that section carries the model facts that override them.

---

# Mandatory reading order — DO NOT WRITE A PROMPT WITHOUT THIS

Past attempts to write prompts directly from this skill body produced lazy, generic results. Each model has its own physics; common rules collapse into mush when applied without model-specific syntax. Read in this order before producing any prompt:

### Step 1 — pick the model → [models.md](references/models.md) + section "Актуальные модели" below

Decide: Nano Banana (NB2 Lite, NB2 or NBP) or GPT Image 2.5 (Flare or Sunburst). The choice changes the prompt syntax fundamentally — natural-language paragraphs vs. labeled 5-slot template, quality settings, which features exist (image grounding only on NB, EXACT TEXT discipline and native transparency on GPT Image, etc.).

`models.md` still says "GPT Image 2" — read every GPT Image 2 row there as GPT Image 2.5 and apply the overrides below.

If the user named a model — confirm and proceed. If not — pick, then state your choice in the output header.

### Step 2 — read **one** model file (the one you picked)

- **Nano Banana** → [nano-banana.md](references/nano-banana.md)
  Image grounding for real locations. Extreme aspect ratios (1:8, 8:1, 4:1). Thinking mode. JSON for 5+ elements. Up to 14 reference images. Why you must NOT write `50mm / f-stop / ISO` numbers. Same prompt style applies to NB2 Lite.

- **GPT Image 2.5** → [gpt-image.md](references/gpt-image.md), then the GPT Image 2.5 part of "Актуальные модели" below.
  From the file: 5-slot template (Scene / Subject / Important Details / Use Case / Constraints), anti-slop banned words, two-column edit logic (Change / Preserve / Constraints), text rules, use-case templates, reference roles. All of that carries over to 2.5 unchanged. Model IDs, quality ladder, sizes, transparency and pricing in that file are for gpt-image-2 — take those from the section below instead.

The model file is non-negotiable. Skipping it is the single biggest cause of weak prompts.

### Step 3 — always read after the model file → [golden-rules.md](references/golden-rules.md)

Universal rules that apply to both models: start with a verb, positive framing, hex colors, quote text, edit don't re-roll, one change per iteration, reference images.

### Step 4 — task-shaped reading (load only what matches the request)

Pick zero or more, depending on what the user asked for:

- Text in image, infographic, diagram, multilingual rendering → [text-rendering.md](references/text-rendering.md)
- Edit existing image (object removal, lighting swap, colorization, restoration, localization) → [editing.md](references/editing.md)
- Character continuity across multiple images / panels → [characters.md](references/characters.md)
- Presentation slides → [slides.md](references/slides.md)
- Sequential narrative (storyboard, comic, panel sequence) → [storyboards.md](references/storyboards.md)
- Sketch → final, wireframes, structural input → [structural.md](references/structural.md)
- 2D → 3D, floor plans, isometric → [dimensional.md](references/dimensional.md)

### Step 5 — read for production language → [creative-direction.md](references/creative-direction.md)

Studio-quality vocabulary for lighting design, camera and hardware, color grading and film stock, materiality and texture. Read when you need precise terms beyond what `golden-rules.md` covers.

### Step 6 — read if structuring a complex prompt → [prompt-framework.md](references/prompt-framework.md)

Universal element checklist (subject, context, action, environment, camera, lighting, mood, materials, palette, format), detail modes (concise / standard / verbose), output structure with parameters and exclusions.

---

# Актуальные модели (сентябрь 2026) — overrides the reference files

## GPT Image 2.5 (OpenAI, релиз 8 сентября 2026)

Работает в API, ChatGPT (все тарифы), ChatGPT Work и Codex. Выше качество (естественнее свет, богаче текстуры), лучше держит объекты с референс-фото, стабильнее в многошаговых правках, лучше понимает сложные layout-инструкции и прозрачный фон.

**Два model ID, голого `gpt-image-2.5` нет** — запрос с ним упадёт:

| Модель | Когда | Характер |
|---|---|---|
| `gpt-image-2.5-flare` | **Default.** Разведка, черновики, соцсети, UI-моки, батчи, большинство одиночных кадров | До ~50% быстрее gpt-image-2 и при этом качественнее |
| `gpt-image-2.5-sunburst` | Финал кампании, product shot с этикеткой, которую нельзя исказить, цепочки правок, try-on / identity, мелкий плотный текст на большом формате, кадр, который будут рассматривать вблизи или печатать | Медленнее, тратит время на мелкую структуру и точность правок |

Снапшоты: `gpt-image-2.5-flare-2026-09-08`, `gpt-image-2.5-sunburst-2026-09-08`. Цена у Flare и Sunburst одинаковая — выбирай по скорости vs точности, а не по деньгам. `gpt-image-2` — legacy: указывай его только если пользователь сам попросил или его пайплайн закреплён на этой версии. `gpt-image-1-mini` для дешёвых батчей больше не нужен — Flare на `low` дешевле цента.

Типовой рабочий цикл: Flare на `low`/`medium` → отбор → финал на Sunburst `high` (или `xhigh` для героя).

**Quality — теперь шесть ступеней:** `low | medium | high | xhigh | max | auto`.

| Quality | ≈ $ за 1024×1024 | Когда |
|---|---|---|
| `low` | 0.006 | Превью, варианты, батч |
| `medium` | 0.013 | Стартовая точка по умолчанию |
| `high` | 0.053 | Мелкий текст, инфографика, портреты, identity-правки, бренд-ассеты |
| `xhigh` | 0.094 | Утверждённый финал: плотная типографика, печать, крупный формат |
| `max` | 0.21 | Только hero-кадр после утверждения. Для разведки — никогда |

Почему так: в 2.5 каждая ступень ест больше токенов, чем в gpt-image-2 (2.5 `high` ≈ 2.0 `medium`), и качество двигает цену сильнее размера (low→max ≈ ×36, 1K→4K < ×3). Поэтому дорогие ступени — только для финала.

**Размер:** любой `WIDTHxHEIGHT`, обе стороны кратны 16, пропорция от 1:3 до 3:1, максимум `3840x2160`. Всё выше ~3,69 Мп (2560×1440) OpenAI считает экспериментальным — для 4K закладывай перегенерации. Стандартные: `1024x1024`, `1536x1024`, `1024x1536`, `auto`. Пропорции экстремальнее 3:1 по-прежнему только Nano Banana.

**Прозрачный фон — теперь рабочий инструмент** (на gpt-image-2 был preview). Параметры `background: transparent` + `output_format: png` или `webp`. Используй для стикеров, иконок, вырезанных продуктов, элементов для презентаций и сайтов. В промпте: «isolated on a transparent background, clean alpha edges, no drop shadow, no background plate». Предупреди пользователя проверять альфа-канал в самом файле, а не по шахматке на превью.

**Референсы:** до 16 картинок с ролями — как в `gpt-image.md`. 2.5 лучше узнаваемо сохраняет объекты и людей с фото и держит стиль по всей серии: для серии пиши одну «style lock» строку и повторяй её дословно в каждом промпте.

**Правки:** 2.5 стабильнее меняет только то, что просили, и меньше деградирует от раунда к раунду. Это бонус, а не замена дисциплины: Change / Preserve / Constraints и повтор preserve-списка каждую итерацию остаются обязательными. Длинные цепочки правок — на Sunburst. Для точечной правки в API есть `mask`.

**Переписывание промпта:** в ChatGPT и Responses API модель может переформулировать промпт (`revised_prompt`). Критичные требования — точный текст, число объектов, что сохранить — держи отдельными помеченными строками, чтобы они пережили переписывание.

**Если промпт пойдёт в ChatGPT (Images 2.5), а не в API:** параметров там нет, поэтому формат и фон пиши словами прямо в промпте («landscape 3:2», «transparent background PNG»). Подскажи пользователю новые инструменты интерфейса, когда они к месту:
- **Sketch** — нарисовать раскладку прямо в ChatGPT и приложить как визуальный референс (layout постера, слайда, UI);
- **комментарии на картинке** — отметить область и написать одну правку: точнее, чем описывать место словами;
- **Templates** — готовые заготовки для постеров, мерча и других популярных форматов;
- ведение правок в **одном чате** — 2.5 держит консистентность по длинной цепочке.

## Nano Banana 2 Lite (Google, июнь 2026)

`gemini-3.1-flash-lite-image`, ≈ $0.034 за картинку 1K, генерация около 4 секунд. Держит промпт, персонажа и читаемый текст, но уступает NB2 и NBP в сложных сценах. Для быстрых черновиков, раскадровок-набросков и массовой генерации. Стиль промпта — как у NB (натуральный язык). Grounding и thinking для Lite не заявлены — если нужны точные реальные места или сложная пространственная логика, бери NB2 / NBP.

## Поправки к таблице выбора в models.md

- Дешёвая массовая генерация → **NB2 Lite** или **GPT Image 2.5 Flare `low`**.
- Ассет с прозрачным фоном (стикер, иконка, cutout) → **GPT Image 2.5** с `background: transparent`.
- Финал с точными правками, этикетками, identity → **GPT Image 2.5 Sunburst**.
- Всё, где в models.md стоит «GPT Image 2» → **GPT Image 2.5 Flare** по умолчанию.

---

# Output format

When you return the prompt, structure it like this:

```
Model: <nano-banana-2-lite | nano-banana-2 | nano-banana-pro | gpt-image-2.5-flare | gpt-image-2.5-sunburst | gpt-image-2 (legacy)>
Quality: <low | medium | high | xhigh | max>        (only for GPT Image)
Size / Ratio: <e.g. 1536x1024 or 16:9>
Background: <transparent, png>                       (only when the asset needs alpha; GPT Image)

Prompt:
<the prompt text, ready to copy>

Notes:
- <anything you inferred or assumed because the user did not specify>
- <if the prompt goes to ChatGPT UI: which tool to use there — Sketch / comment / same chat>
```

For edits, also include an explicit preserve-list (mandatory for GPT Image, recommended for Nano Banana):

```
Change: <one concrete thing>
Preserve: <face, pose, lighting, framing, geometry, ...>
Constraints: <no extra objects, no drift, ...>
```

---

# Final response style

Prefer: ready-to-copy prompts, hex colors, concrete materials, named compositions, model-specific syntax (5-slot for GPT Image, natural prose for Nano Banana).

Avoid: tag soup ("cool, modern, 4k"), vague praise ("stunning, epic, masterpiece" — actively hurts GPT Image), negative framing ("no people, no cars" — invert to positive), external comparisons ("like Apple ad" — describe the visual properties instead), numerical lens parameters in Nano Banana prompts (it ignores them), `max` quality for drafts.