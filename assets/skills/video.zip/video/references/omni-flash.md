# Gemini Omni Flash reference (Google)

Source: Google Gemini API docs — "Create and edit videos with Gemini Omni Flash"
(https://ai.google.dev/gemini-api/docs/omni). Model is in **preview**; behavior can shift.

## Contents

1. What Omni Flash is
2. Specs and how it's called
3. The behavior that changes your prompt: single scene vs auto-montage
4. Prompt structure and length
5. Negatives live inside the prompt (no negative field)
6. Audio (native, describe it)
7. Timed events and self-directed montage
8. On-screen text
9. Image inputs and role tags
10. Stateful iterative editing
11. Meta-prompting
12. Limits that shape prompt craft
13. Failure modes and fixes
14. Skeletons and worked examples

---

## 1. What Omni Flash is

`gemini-omni-flash-preview` is Google's fast, natively multimodal video model. Three properties set it apart and each one changes how you write for it:

- **Native multimodality.** Text, image, audio, and video are handled in one model, so a single prompt can carry scene, motion, on-screen text, and a described soundtrack together, with audio generated in sync (like Veo).
- **Conversational, stateful editing.** Through the Interactions API you refine a generated clip across turns. You describe a change, the model applies it and preserves everything you did not mention. This makes "edit" a first-class prompt mode, not just generation.
- **World knowledge.** It leans on Gemini's grasp of physics, history, science, and culture, so prompts can reference real concepts and expect them rendered plausibly.

Where Veo is the studio audio/dialogue tool and Seedance is the fast multi-shot dramatist, Omni Flash is the **fast multimodal draft-and-revise** tool: quick generation, then natural-language edits on top.

## 2. Specs and how it's called

Omni Flash is driven through the **Interactions API**, not a `--flag` prompt string. The creative prompt is the `input`; the knobs live in structured config. You do not need to write code to use this skill, but naming the parameters lets the user copy real settings.

- **Aspect ratio.** `response_format.aspect_ratio` — `"16:9"` (default, landscape) or `"9:16"` (portrait). There is no free-form resolution flag in the prompt text.
- **Task hint.** `generation_config.video_config.task` — one of `text_to_video`, `image_to_video`, `reference_to_video`, `edit`. If omitted the model infers intent from the prompt and attachments. Set it when you want to remove ambiguity (e.g. force `image_to_video` so a reference isn't treated as a literal first frame).
- **Delivery.** For clips over ~4 MB, request `response_format.delivery = "uri"` and poll until the file is `ACTIVE`. Inline base64 is fine for small clips.
- **Editing memory.** Pass `previous_interaction_id` to keep editing a prior result (see §10). Note that `store=false` speeds up generation but disables this follow-up editing.
- **Watermark / language.** Every output carries an invisible SynthID watermark. English is the only fully tested prompt language.

When you hand the user a prompt, lead with a short header naming the model, the aspect ratio, and whether it's a fresh generation or an edit turn. Keep the creative text model-agnostic and put the settings in the header.

## 3. The behavior that changes your prompt: single scene vs auto-montage

This is the single most important Omni-specific fact. **By default Omni Flash builds a montage** — it splits your idea into several different shots and tries to construct an interesting little story on its own. That is the opposite of most single-clip models.

Consequences for the writer:

- If you want **one continuous take**, you must say so explicitly. Use phrasing like *"in a single continuous scene," "one continuous unbroken shot," "no cuts."* Without it, expect the model to cut.
- If you want a **montage**, you can lean into the default and steer it with timed beats (§7) instead of fighting it.

Continuous-take example from the docs:

```text
Continuous, unbroken handheld shot of a fluffy tabby cat sitting on a sunny windowsill, looking out into a leafy garden. The cat's tail twitches slowly, and its ears rotate slightly toward ambient noises. Sunbeams illuminate dust motes in the air. Sound design: gentle breeze, distant bird chirps. No dialogue.
```

Notice it still obeys the skill's Details Law: environmental pressure (sunbeams, dust motes), physical micro-action (tail twitch, ears rotating), and a sound motif (breeze, chirps). Omni's auto-montage tendency is not an excuse to skip the three-detail check — it makes it more important, because a vague prompt hands the model total authorship.

## 4. Prompt structure and length

Omni takes rich natural-language prompts. Reuse the universal skeleton (subject/action → environment → camera → light → style → audio), and add the two Omni-specific decisions up front: **scene structure** (one take vs montage) and **sound intent**.

Precision beats brevity, especially for motion. The docs are explicit: "make it move" style prompts produce weak results; detailed camera movement, subject movement, and environmental effects produce convincing ones. So spend your words on *what physically moves and how the camera responds*, not on adjectives like "cinematic" or "masterpiece."

## 5. Negatives live inside the prompt (no negative field)

Omni Flash has **no dedicated negative-prompt field** (and ignores system instructions, temperature, top_p, and stop sequences). To exclude something, state the negation in plain language inside the main prompt:

```text
No dialogue.
No text on screen.
No additional sound effects.
Do not show the original drawing in the final video.
```

Keep negatives short and specific. This is also how you suppress Omni's habit of auto-adding a soundtrack or captions you didn't ask for.

## 6. Audio (native, describe it)

Like Veo, Omni generates sound with the picture. Left unguided it will invent a soundtrack, which often won't match your intent — so **describe the audio you want**, especially music:

```text
Include calm background music.
The clip has an energetic techno beat.
Audio: a quiet, crackly radio in the background playing an old song.
```

If you want silence or ambient-only, say so with a negative (§5). Omni does not currently accept uploaded audio files and does not do voice editing, so all sound direction is textual.

## 7. Timed events and self-directed montage

Omni understands timing in natural language — no special syntax required — which makes it strong at beat-driven or fast montage sequences. You can pin events to seconds:

```text
At 3 seconds a woman enters the scene.
On the 5th second a chorus kicks in on the soundtrack.
Every 2 seconds it re-cuts to a new shot.
Fast-cut style: switch location every half second (12 frames at 24 fps).
```

It also accepts an explicit timecode block, which is the cleanest way to storyboard a montage in one prompt:

```text
[0-3s] A person is walking.
[3-6s] They stop and turn around.
[6-10s] They start running.
```

Map this straight from the skill's rhythm ladder: each bracket is a beat with its own function, action, and (if wanted) sound event. This is the Omni-native way to deliver Output format B/C without stitching separate generations.

## 8. On-screen text

Omni renders legible on-screen text, which most video models fumble. If text appears — even in the background — **spell out exactly what it should say**, or the model will invent it:

```text
On-screen, one word at a time: "did, you, know, that, Omni, can, do, awesome, text?" Each word appears for 1 second in a different animated style. No dialogue.

A street sign reads "This is the Omni AI generation", a storefront reads "Everything you need from AI", and a car has a licence plate reading "OMN111".
```

Use this for titles, lower-thirds, signage, and product labels instead of adding text in post.

## 9. Image inputs and role tags

You can attach one or more images. Omni will decide how to use them from the prompt, but you get better control by tagging roles.

**Image-to-video.** Attach an image and describe the motion. Add a task hint (`image_to_video`) if you don't want the image treated as a literal first frame. Docs example — a drawing used only as a motion guide:

```text
turn this into realistic footage, using the drawing only as a guide for movement, do not show the drawing in the final video
```

**Subject reference.** Attach several images (e.g. a cat and a ball of yarn) and describe them interacting: *"A cat playfully batting at a ball of yarn."*

**Simple role tags (preferred when roles are obvious).**

- `<FIRST_FRAME>` — use this image as the opening frame: `<FIRST_FRAME> a woman is walking`
- `<IMAGE_REF_N>` — use this image as a reference, 0-indexed: `in the style of <IMAGE_REF_0> a woman <IMAGE_REF_1> is walking`

Multi-reference fashion example:

```text
[0-3s] A studio fashion sequence. Starting with woman <IMAGE_REF_0>, she is holding <IMAGE_REF_1>
[3-6s] Then we see the man <IMAGE_REF_2> holding <IMAGE_REF_3>
[6-10s] And finally another woman <IMAGE_REF_4> holding <IMAGE_REF_5> while walking.
```

**Explicit statements (for many images / mixed roles).** Declare sources and references with prefix tags, then restate in natural language at the end:

```text
[# Sources <FIRST_FRAME>@Image1] [# References <IMAGE_REF_0>@Image2] a woman <IMAGE_REF_0> is walking. Use Image1 as the starting frame. Use Image2 as a reference for the video generation.
```

Guidance suffixes that help: *"Use this image as the starting frame."* for a first frame, and *"Use the given image(s) as references for video generation. The images should not be used as literal initial frames."* for references.

## 10. Stateful iterative editing

This is Omni's signature workflow and a distinct prompt mode. Generate a clip, then send follow-up prompts that carry `previous_interaction_id`; the model applies the change and keeps everything you didn't mention. You never re-upload or re-describe the whole scene.

**Edit prompts must be simple.** This is the opposite of generation, where detail helps. Over-specified edits cause unintended changes. Isolate one change per turn and, when touching a specific element, append **"Keep everything else the same."** to lock the rest.

```text
Turn 1 (generate): A woman playing violin outdoors.
Turn 2 (edit):     Make the violin invisible.
```

More edit-prompt examples: *"Make this video anime." / "Put a stylish hat on this person." / "Change the lighting to be more dramatic." / "Change the text on the sign to 'Omni Flash'."*

Simplify busy edits into their essence:

- Avoid: *"Please remove the cell phone the person is holding and fill in the background so their hand looks empty."*
  Prefer: *"Make the phone invisible. Keep everything else the same."*
- Avoid: *"Add a small black cat that runs in from the right, jumps onto his lap, and he strokes its head while looking down."*
  Prefer: *"Add a cat that jumps onto his lap, he begins to pet it. Keep everything else the same."*

You can also edit **your own** footage: upload via the Files API and attach it as a document, then give a simple edit instruction. (Region and content limits apply — see §12.)

## 11. Meta-prompting

Omni responds to instructions about *how* to make the video, not just what's in it. Layer these on top of the scene when you want a quality or density lift:

```text
Pay close attention to the smallest details, facial expression, and micro-moments to create a very rich, detailed, yet completely natural scene.
Be extremely deliberate in describing characters and setting. Apply costume-design principles to the characters. Describe people, items, and objects in detail.
Fill the background with many fitting details so the scene reads as real and lived-in.
Make a fast-paced clip that shows a new rare [thing] every 1 second, upbeat music, and an on-screen text label for each item.
```

Reach for meta-prompts when a plain scene comes back flat, or when you want a specific density/pacing behavior (the last one is a montage engine in a single line).

## 12. Limits that shape prompt craft

- **No negative field / no sampling controls.** Put negations in the prompt (§5). Don't promise the user temperature or seed control — Omni exposes neither.
- **Uploaded-media limits.** Editing uploaded media of recognizable people is unsupported; uploading/editing media containing minors is unsupported in the EEA, Switzerland, and the UK. Editing *uploaded videos* is likewise unavailable in the EEA, Switzerland, and the UK — but editing *model-generated* videos still works there. Don't build a workflow around uploaded-footage editing for those regions.
- **One video at a time.** Multi-video reasoning/reference is unsupported and degrades output. The API accepts clips up to 3s but currently mishandles them.
- **No video extension or interpolation** (no "generate the tween between first and last frame"), **no voice editing**, **no audio-file upload**, **no YouTube source**.
- **English only, fully tested.** Other languages may work but are unverified — write the final prompt in English unless the user insists otherwise.

If a request hits one of these walls, say so and offer the nearest supported path (e.g. re-generate rather than extend; describe audio rather than upload it).

## 13. Failure modes and fixes

### Output got chopped into a montage you didn't want
Add an explicit single-take instruction: *"one continuous unbroken shot, no cuts."* (§3). This is the most common Omni surprise.

### A soundtrack or captions appeared unbidden
Omni auto-adds audio and sometimes text. Suppress with negatives: *"No music. No on-screen text."* Or replace with a described soundtrack (§6).

### Image-to-video shows the source image / drawing in the clip
State it: *"do not show the drawing in the final video, use it only as a motion guide,"* and set `task: image_to_video`.

### An edit changed things you wanted kept
The edit prompt was too detailed or too broad. Cut it to one change and add *"Keep everything else the same."* (§10).

### Text on screen came out as gibberish or wrong words
Spell the exact string in quotes and, if needed, say where it sits in frame (§8).

### Motion looks limp
Replace vague motion verbs with specific camera movement + subject movement + environmental effect. "Make it move" underperforms every time (§4).

### Wanted to extend a clip and it won't
Extension/interpolation is unsupported. Re-generate a longer beat plan with a timecode block (§7) instead.

## 14. Skeletons and worked examples

### Single-take generation skeleton

```text
[One continuous unbroken shot / no cuts] of [subject] in [environment].
[Camera framing + movement]. [Lighting direction + color]. [Style/mood].
[Physical micro-action]. [Environmental pressure detail].
Sound design: [ambient + motif]. [Negatives, e.g. No dialogue.]
```

### Montage skeleton (timecode)

```text
[0-Xs] [beat 1: function, action, camera].
[X-Ys] [beat 2: function, action, camera].
[Y-Zs] [beat 3: final image].
[Global style + soundtrack description]. [Negatives.]
```

### Edit-turn skeleton (with previous_interaction_id)

```text
[Single change stated plainly]. Keep everything else the same.
```

### Worked example — continuous product hero (16:9)

Header: `Omni Flash · text_to_video · 16:9 · single take`

```text
One continuous unbroken shot, no cuts. A cream ceramic coffee cup sits on a sunlit oak table by a rain-streaked window at dawn. Slow push-in, shallow depth of field. Steam curls upward and catches the warm window key light; a single droplet slides down the glass behind it. The surface of the coffee ripples once as a distant train passes.
Sound design: soft rain on glass, low room tone, one ceramic clink. Include calm, warm background music. No dialogue. No on-screen text.
```

### Worked example — self-directed montage with on-screen text (9:16)

Header: `Omni Flash · text_to_video · 9:16 · montage`

```text
[0-2s] Close on hands snapping a film clapperboard; the slate reads "OMNI FLASH".
[2-5s] Whip to a neon night street, a woman turns to camera, city lights streaking behind her.
[5-8s] Cut to an aerial rush over a coastline at golden hour, gulls scattering.
Fast, upbeat electronic soundtrack that builds each cut. Rich background detail in every shot, lived-in and real. No dialogue.
```

### Worked example — image-to-video from a drawing

Header: `Omni Flash · image_to_video · 16:9 · reference image attached`

```text
Turn this into realistic footage, using the drawing only as a guide for movement. A clownfish bursts up out of the water in a slow, weighty arc, droplets trailing and catching the light, then arcs back down. Do not show the drawing in the final video.
Sound design: a single water whoosh and splash, quiet reef ambience. No music.
```
