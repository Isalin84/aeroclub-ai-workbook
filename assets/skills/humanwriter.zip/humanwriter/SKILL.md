---
name: humanwriter
description: >
  Rewrites AI-generated or AI-assisted text to sound authentically human by diagnosing and eliminating 29 documented AI writing patterns. ALWAYS use when the user asks to "make this sound more human", "убери AI-стиль", "перепиши по-человечески", "humanize", "de-AI", "remove robot tone", "rewrite to avoid AI detection", "звучит как ChatGPT/Claude", or pastes any text and asks why it sounds fake/corporate/generic. Also trigger when user asks to analyze text for AI patterns, check if something reads as AI-written, match their personal writing voice, or turn any AI draft into authentic copy. Works on Russian AND English text — full pattern coverage for both languages. Always follow the Diagnose → Draft → Self-audit → Final loop.
---

# humanwriter

Transform AI-generated or AI-assisted text into authentic human prose by systematically identifying and eliminating the patterns that give AI writing away.

Based on Wikipedia's **"Signs of AI Writing"** — a living field guide compiled by WikiProject AI Cleanup from thousands of real AI-generated submissions. 29 documented patterns.

---

## The Core Loop

**Every humanwriter task follows this sequence:**

1. **DIAGNOSE** — scan the input and list every AI pattern found (with quotes from the text)
2. **DRAFT** — produce a clean human version
3. **SELF-AUDIT** — ask internally: *"What still makes this obviously AI-generated?"* List remaining tells briefly
4. **FINAL** — revise based on the audit; present the final version + brief "What changed" note

Do not skip the diagnosis. Showing the user *what* you found builds trust and helps them learn to catch these patterns themselves.

---

## Voice Calibration (Optional but Powerful)

If the user provides a sample of their own previous writing, analyze it **before** rewriting:

1. **Sentence length patterns** — short and punchy? long and flowing? mixed?
2. **Word choice level** — casual? academic? somewhere between?
3. **Punctuation habits** — lots of dashes? parenthetical asides? semicolons?
4. **Transitions** — explicit connectors, or just start the next point?
5. **Any verbal tics or recurring phrases**

**Match their voice in the rewrite** — don't just remove AI patterns, replace them with patterns from the sample. If they write short sentences, don't produce long ones.

How to trigger: *"Humanize this. Here's a sample of my writing: [sample]. Now fix: [text]"*

When no sample is provided: fall back to natural, varied, opinionated voice (see Personality section below).

---

## Personality and Soul

Avoiding AI patterns is only **half** the job. Sterile, voiceless writing is just as obvious as slop — it just fails differently.

**Signs of soulless writing (even if technically "clean"):**
- Every sentence is the same length and structure
- No opinions, just neutral reporting
- No acknowledgment of uncertainty or mixed feelings
- No first-person perspective when appropriate
- Reads like a Wikipedia article or press release

**How to add voice:**
- **Have opinions.** "I genuinely don't know how to feel about this" beats a neutral pros/cons list
- **Vary rhythm.** Short punchy sentence. Then one that takes its time getting where it's going. Mix it up.
- **Acknowledge complexity.** "Impressive but also kind of unsettling" beats "impressive"
- **Use "I" when it fits.** "Here's what gets me..." signals a real person thinking
- **Be specific about feelings.** Not "this is concerning" but exactly what feels off
- **Let some mess in.** Perfect structure feels algorithmic. Tangents and half-formed thoughts are human.

---

## The AI Writing Pattern Checklist (29 patterns)

Use this as your scanning lens. Check every category.

### 🔴 TONE PATTERNS (most damaging)

| Pattern | AI example | Human fix |
|---|---|---|
| **Significance inflation** | "marking a pivotal moment in the evolution of...", "stands as a testament to", "plays a vital role" | State the fact plainly. Drop the framing. |
| **Promotional/brochure language** | "rich cultural heritage", "breathtaking", "groundbreaking", "nestled in the heart of" | Be specific or delete. What exactly makes it notable? |
| **Relentlessly upbeat** | Every problem has a solution. No friction, no failure, no doubt. | Add a real edge. Acknowledge what's actually hard. |
| **Obsequious openers** | "Great question!", "Certainly!", "Absolutely!" | Delete entirely. Just answer. |
| **Formulaic challenges** | "Despite these challenges... continues to thrive." | Specific facts about actual obstacles. |
| **Generic positive conclusions** | "The future looks bright. Exciting times lie ahead." | End with a specific fact or real plan. |
| **Sycophantic tone** | "You're absolutely right that this is a complex topic." | Respond directly to the substance. |

**Russian-specific 🔴:**
> "нельзя не отметить" · "актуальность данной темы не вызывает сомнений" · "в условиях современных реалий" · "важно подчеркнуть, что" · "заслуживает особого внимания" · "несмотря на вызовы, [X] продолжает развиваться"

---

### 🟠 STRUCTURAL PATTERNS

| Pattern | AI example | Human fix |
|---|---|---|
| **Negative parallelisms** | "It's not just a product — it's a movement." | Just say what it is. Nobody had the wrong idea. |
| **Russian "не X, а Y" contrast sentences** 🇷🇺 | "Не просто инструмент, а система которая сама..." / "Это не барьеры для отказа — это контрольный список." / "Теряют не деньги — они теряют преимущество." | Переписать прямым утверждением без противопоставления: "ИИ становится системой, которая сама..." / "Это контрольный список при внедрении." Если противопоставление необходимо — встроить в нормальное предложение, а не выносить в риторическую конструкцию. |
| **Dramatic split fragments** 🇷🇺 | "Это уже не тренд. Это рабочий стандарт." / "Онбординг — очевидное применение. Но не единственное." | Слить в одно предложение: "Это уже рабочий стандарт." / "Онбординг — очевидное, но не единственное применение." ИИ дробит предложения для создания «удара», в русской прозе это выглядит искусственно. |
| **Anaphoric preposition repetition** 🇷🇺 | "Без звонков, без согласований, без задержки." | Обычное русское перечисление: "без звонков, согласований и задержек." Анафорический повтор предлога — ораторский приём, в деловой прозе звучит как имитация пафоса. |
| **Nominal fragment sentences** 🇷🇺 | "Владение интеллектуальной собственностью вместо зависимости от внешних вендоров." (фраза без сказуемого как итог абзаца) | Сделать полным предложением: "Это снижает зависимость от внешних вендоров." Безглагольные конструкции-выводы — типичный AI-приём для имитации афористичности. |
| **Tailing negations** | "The options come from the selected item, no guessing." | "...without forcing you to guess." |
| **Superficial -ing analyses** | "...symbolizing bluebonnets, reflecting the community's connection to the land." | Cut the tailing clause or cite an actual source. |
| **Transition word crutches** | "Moreover,", "Furthermore,", "Additionally," every paragraph | Vary connectives or let ideas flow without them. |
| **Vague attributions** | "Some experts argue...", "Observers have noted...", "Industry reports suggest..." | Name the source or delete. |
| **Rule of three** | "innovative, transformative, and groundbreaking" | One precise word instead of three vague ones. |
| **False ranges** | "from the Big Bang to dark matter, from X to Y" | List the topics directly. |
| **Synonym cycling** | "protagonist... the main character... the central figure... the hero" | Repeat the clearest word. Humans don't fear repetition. |
| **Signposting announcements** | "Let's dive in", "Here's what you need to know", "Without further ado" | Start with the content. Don't announce it. |
| **Fragmented headers** | `## Performance` followed by "Speed matters." then real content | Let the heading do the work; cut the filler sentence. |

**Russian-specific 🟠 — banned words in transitions:**
> "таким образом" · "следует отметить, что" · "в заключение хотелось бы отметить" · "подводя итог, можно сказать" · "рассмотрим подробнее" · "что не менее важно" · "стоит также упомянуть" · "герой/персонаж/главное действующее лицо/протагонист" (synonym cycling)

**Russian-specific 🟠 — contrast & drama constructions (HIGH PRIORITY):**

ИИ строит «punch» через риторические конструкции, которые в русском тексте сразу выдают нечеловеческое происхождение. Три главных:

**1. "Не X, а Y" / "Не просто X, а Y" как отдельное предложение:**
- ❌ "Не просто инструмент для создания видео, а система, которая сама отслеживает изменения."
- ❌ "Это не барьеры для отказа от внедрения — это контрольный список при внедрении."
- ❌ "Те, кто занял выжидательную позицию, теряют не деньги — они теряют конкурентное преимущество."
- ✅ Переписать: "ИИ станет системой, которая сама отслеживает изменения." / "Это контрольный список, требующий проверки при внедрении."

**2. "Это X. Это Y." — дробление в два удара:**
- ❌ "Это уже не тренд. Это рабочий стандарт."
- ❌ "Онбординг — очевидное применение. Но не единственное."
- ✅ "Это уже рабочий стандарт." / "Онбординг — очевидное, но не единственное применение."

**3. Анафора с предлогом ("без X, без Y, без Z"):**
- ❌ "Без звонков, без согласований, без задержки."
- ✅ "Без звонков, согласований и задержек." / "Всё происходит без звонков, согласований и задержек."

---

### 🟡 VOCABULARY PATTERNS

**English AI Banned Word List** — appear with unnatural frequency post-2023:
> delve · intricate · tapestry · pivotal · underscore · landscape (abstract) · foster · testament · enhance · crucial · robust · leverage · nuanced · comprehensive · holistic · synergy · paradigm · transformative · multifaceted · groundbreaking · game-changing · seamlessly · notably · importantly · vibrant · showcase · garner · interplay

**Copula avoidance** — replace with simple "is/are/has":
> "serves as" → "is" · "stands as" → "is" · "boasts" → "has" · "features" → "has/includes" · "functions as" → "is" · "marks" → "is"

**Hyphenated word pair overuse** (AI hyphenates these with perfect consistency; humans don't):
> cross-functional · data-driven · client-facing · decision-making · end-to-end · real-time · high-quality · long-term · well-known

**Persuasive authority tropes** (pretend to cut to a deeper truth, then restate something ordinary):
> "The real question is...", "At its core...", "In reality...", "What really matters...", "Fundamentally...", "The heart of the matter is..."

**Russian AI Banned Word List:**
> ключевую роль · в рамках · неотъемлемой частью · стремительно развивающийся · комплексный подход · в условиях · данного контекста · важно отметить · является · осуществляется · обеспечивает · данный/данная/данное · способствует · позволяет говорить о · свидетельствует о · инновационный · эффективный · оптимальный · системный · устойчивый · ключевой

**Russian structural clichés to eliminate:**
> "являясь [noun], он/она..." (dangling participle opener)
> "что позволяет сделать вывод о том, что..."
> "в связи с вышесказанным"
> "на сегодняшний день"
> "в современных условиях"
> "это свидетельствует о том, что"
> Gerund chains: "являясь... обеспечивая... позволяя... способствуя..."

---

### 🔵 FORMATTING PATTERNS

| Pattern | Fix |
|---|---|
| **Em dash overuse** — used everywhere — like this | Reserve for genuine asides. Max 1–2 per page. Prefer commas or periods. |
| **Russian em dash misuse** 🇷🇺 | "С ИИ ситуация изменилась — и цифры это подтверждают." / "Введённые стандарты — уже неактуальны." / "Снятый инструктаж — требует пересъёмки." / "38% руководителей сохраняют осторожность — и правильно делают." | В русском языке тире ставится как сказуемое в назывных предложениях ("Москва — столица") или в прямой речи. Оно НЕ используется: (1) как замена запятой перед "и/а/но"; (2) как «пауза для эффекта» внутри предложения; (3) как соединитель двух коротких предложений-ударов. Правило: если можно поставить запятую или просто убрать знак — убери тире. |
| **Boldface overuse** | Bold only truly critical items, sparingly. |
| **Inline-header bullet lists** | **Bold term:** sentence restating the bold → convert to prose |
| **Wall of headers** | Write prose. Headers are for navigation, not decoration. |
| **Title Case In Every Heading** | Use sentence case unless proper nouns. |
| **Emojis in bullets/headings** | 🚀💡✅ → remove entirely from formal/professional text |
| **Curly quotation marks** | Use straight quotes "like this" not "like this" |
| **Numbered lists for non-sequential items** | Use prose or plain bullets when order doesn't matter. |

---

### 🟢 DEPTH PATTERNS

| Pattern | Fix |
|---|---|
| **No personal detail** | Add a specific example, a named reference, a real data point. |
| **Vague generics** | "a popular app" → name it. "many studies" → cite one. |
| **Sanitized difficulty** | Mention the actual obstacle. What was genuinely hard? |
| **Excessive hedging** | "could potentially possibly be argued that it might" → "may" |
| **Filler phrases** | "In order to" → "To" · "Due to the fact that" → "Because" · "At this point in time" → "Now" · "It is important to note that" → delete |
| **Passive voice / subjectless fragments** | "No configuration needed" → "You don't need a config file." |
| **Knowledge-cutoff disclaimers** | "While specific details are limited based on available information..." → find a source or cut the claim |
| **Chatbot artifacts** | "I hope this helps! Let me know if you'd like me to expand..." → delete entirely |

---

## Rewriting Heuristics

Apply in order:

1. **Cut first.** AI text is 30–40% longer than needed. Most promotional and transitional filler can simply be deleted.
2. **Shrink sentences.** Two thoughts → two sentences.
3. **Replace abstractions with specifics.** "Significant growth" → "revenue doubled." "Innovative approach" → describe exactly what was done differently.
4. **Vary rhythm intentionally.** After a long sentence, write a short one. Pause. Then continue.
5. **Find the one honest thing.** What does the writer actually believe? Lead with that.
6. **Add friction.** One honest acknowledgment of difficulty makes the whole piece more trustworthy.
7. **Do the anti-AI pass.** After your first draft, ask internally: *"What still makes this obviously AI-generated?"* Then fix those things before presenting the final version.

---

## Diagnosis Output Format

```
🔍 AI PATTERN DIAGNOSIS
━━━━━━━━━━━━━━━━━━━━━━━━

🔴 TONE
- [Pattern name]: "[quoted example from text]"

🟠 STRUCTURE  
- [Pattern name]: "[quoted example]"

🟡 VOCABULARY
- Banned words found: [list]
- Russian clichés: [list]

🔵 FORMATTING
- [Issue found]

🟢 DEPTH
- [What's missing]

SEVERITY: [High / Medium / Low] — [1 sentence summary]
```

Then: **DRAFT** → brief **Self-audit bullets** ("What still reads as AI?") → **FINAL version** → "What changed" note.

---

## Special Modes

**Analysis only** — user asks for diagnosis, no rewrite: produce only the diagnosis block.

**Quick pass** — user is in a hurry: skip diagnosis, deliver rewrite + 3-bullet "Key fixes" note.

**Context provided** (audience, tone, purpose): factor it in. Human-sounding LinkedIn post ≠ human-sounding technical spec ≠ human-sounding safety procedure.

**Russian text**: apply all patterns — they translate directly. Watch especially for: gerund chains ("являясь... обеспечивая... позволяя..."), official-document register bleeding into informal text, the "Таким образом, можно сделать вывод" closing, and synonym cycling of words like "руководитель/менеджер/управленец/лидер".

**Russian HIGH PRIORITY: the four mechanical patterns ИИ неизменно воспроизводит на русском:**
1. **Длинное тире не по назначению** — перед "и/а/но", как «пауза для удара», в середине фразы. Если можно убрать или поставить запятую — убирай тире.
2. **"Не X, а Y" / "Это не X — это Y"** — риторические контрасты как отдельные предложения. Переписывать прямым утверждением.
3. **"X. Но Y." / "X. И это Y."** — дробление фраз в два удара ради пафоса. Слить в одно предложение.
4. **Анафора с предлогом** ("Без X, без Y, без Z.") — убрать повтор предлога, сделать обычное перечисление.

**Voice matching**: if user provides a writing sample, analyze it first per Voice Calibration section above.

---

## What "Human" Actually Means

Human writing is not just AI writing with banned words swapped out. True human voice has:

- **Specificity** — real names, real numbers, real places
- **Rhythm variation** — controlled pacing, not algorithmic uniformity  
- **Earned confidence** — conviction where warranted, honest uncertainty where not
- **Friction** — the real obstacles, not the sanitized summary
- **A point of view** — the writer's actual position, not a diplomatic overview
- **Soul** — opinions, edge, the occasional half-formed thought

The goal is not to disguise AI output. The goal is to produce writing that a real person with real knowledge would actually write.
